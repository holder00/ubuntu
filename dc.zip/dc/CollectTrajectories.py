# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 22:53:05 2024

@author: takumi
"""

import numpy as np
import torch

def _random_collect(env,ep_num,trajectories):
    
    for i in range(ep_num):
        state = env.reset()
        actions = []
        states = []
        rewards = []
        terminals = []
        truncates = []
        terminal, truncate = False, False
        while not terminal and not truncate:
            action = env.action_space.sample()
            state, reward, terminal, truncate, info = env.step(action)
           
            actions.append(action)
            states.append(state)
            rewards.append(reward)
            temp = 0 if terminal else 1
            terminals.append(temp)
            temp = 0 if truncate else 1
            truncates.append(temp)
            
        actions = np.array(actions,dtype=np.float32) 
        states = np.array(states,dtype=np.float32)
        rewards = np.array(rewards,dtype=np.float32)
        terminals = np.array(terminals,dtype=np.float32)
        truncates = np.array(truncates,dtype=np.float32)
        
        trajectories.append({'actions':actions,
                             'observations':states,
                             'rewards':rewards,
                             'terminals':terminals,
                             'dones':truncates})
        print(f'{i+1} epsodes collected')
    return trajectories

def _policy_collect(env,ep_num,trajectories,policy,device):
    state = env.reset()
    for i in range(ep_num):
        steps = 0
        state = env.reset()
        actions = []
        states = [state[0]]
        rewards = []
        terminals = []
        truncates = []
        returns_to_go = [100.]
        timesteps = [steps]
        terminal, truncate = False, False
        policy.to(device='cpu')
        states_tensor = torch.from_numpy(np.array(states)).reshape([1,1,-1])
        actions_tensor = torch.from_numpy(np.array(actions)).reshape([1,1,-1])
        rewards_tensor = torch.from_numpy(np.array(rewards)).reshape([1,1,-1])
        returns_to_go_tensor = torch.from_numpy(np.array(returns_to_go).reshape([1,1,-1]).astype(np.float32))
        timesteps_tensor = torch.from_numpy(np.array(timesteps))
        states = []
        while not terminal and not truncate:
            action = policy.get_action(states = states_tensor,
                                      actions = actions_tensor,
                                      rewards = rewards_tensor,
                                      returns_to_go = returns_to_go_tensor,
                                      timesteps = timesteps_tensor)
            action = action.detach().clone().to('cpu').numpy()
            state, reward, terminal, truncate, info = env.step(action)
           
            actions.append(action)
            states.append(state)
            rewards.append(reward)
            temp = 0 if terminal else 1
            terminals.append(temp)
            temp = 0 if truncate else 1
            truncates.append(temp)
            steps += 1
            states_tensor = torch.from_numpy(np.array(states)).reshape([1,-1,state.shape[0]])
            
            actions_tensor = torch.from_numpy(np.array(actions)).reshape([1,-1,action.shape[0]])
            rewards_tensor = torch.from_numpy(np.array(rewards)).reshape([1,-1,1])
            returns_to_go_tensor = torch.from_numpy(np.array(returns_to_go).reshape([1,-1,1]).astype(np.float32))
            timesteps_tensor = torch.from_numpy(np.array(steps))
            
            # env.render()
        actions = np.array(actions,dtype=np.float32) 
        states = np.array(states,dtype=np.float32)
        rewards = np.array(rewards,dtype=np.float32)
        terminals = np.array(terminals,dtype=np.float32)
        truncates = np.array(truncates,dtype=np.float32)
        
        trajectories.append({'actions':actions,
                             'observations':states,
                             'rewards':rewards,
                             'terminals':terminals,
                             'dones':truncates})
        print(f'{i+1} epsodes collected')
    policy.to(device=device)
    return trajectories

def collect_trajectory(env,ep_num,trajectories,policy=None,device=None):
    if policy == None:
        trajectories = _random_collect(env,ep_num,trajectories)
    else:
        device = 'cpu' if device == None else 'cuda'
        trajectories = _policy_collect(env,ep_num,trajectories,policy,device)
    print('='*50)
    print('Finish Collect')
    print('='*50)
    return trajectories

def view_trajecory(env,ep_num,policy):
    state = env.reset()
    for i in range(ep_num):
        steps = 0
        state = env.reset()
        actions = []
        states = [state[0]]
        rewards = []
        terminals = []
        truncates = []
        returns_to_go = [100.]
        timesteps = [steps]
        terminal, truncate = False, False
        policy.to(device='cpu')
        states_tensor = torch.from_numpy(np.array(states)).reshape([1,1,-1])
        actions_tensor = torch.from_numpy(np.array(actions)).reshape([1,1,-1])
        rewards_tensor = torch.from_numpy(np.array(rewards)).reshape([1,1,-1])
        returns_to_go_tensor = torch.from_numpy(np.array(returns_to_go).reshape([1,1,-1]).astype(np.float32))
        timesteps_tensor = torch.from_numpy(np.array(timesteps))
        states = []
        while not terminal and not truncate:
            action = policy.get_action(states = states_tensor,
                                      actions = actions_tensor,
                                      rewards = rewards_tensor,
                                      returns_to_go = returns_to_go_tensor,
                                      timesteps = timesteps_tensor)
            action = action.detach().clone().to('cpu').numpy()
            state, reward, terminal, truncate, info = env.step(action)
           
            actions.append(action)
            states.append(state)
            rewards.append(reward)
            temp = 0 if terminal else 1
            terminals.append(temp)
            temp = 0 if truncate else 1
            truncates.append(temp)
            steps += 1
            states_tensor = torch.from_numpy(np.array(states)).reshape([1,-1,state.shape[0]])
            
            actions_tensor = torch.from_numpy(np.array(actions)).reshape([1,-1,action.shape[0]])
            rewards_tensor = torch.from_numpy(np.array(rewards)).reshape([1,-1,1])
            returns_to_go_tensor = torch.from_numpy(np.array(returns_to_go).reshape([1,-1,1]).astype(np.float32))
            timesteps_tensor = torch.from_numpy(np.array(steps))
            
            env.render()