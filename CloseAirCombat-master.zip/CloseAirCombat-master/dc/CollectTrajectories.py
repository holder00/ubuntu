# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 22:53:05 2024

@author: takumi
"""

import numpy as np
import torch

def _random_collect(env,ep_num,trajectories):
    
    for i in range(ep_num):
        state, share_state = env.reset()
        actions = []
        states = []
        rewards = []
        terminals = []
        truncates = []
        terminal, truncate = False, False
        while not terminal and not truncate:
            action = env.action_space.sample()
            state, share_state, reward, terminal, truncate, info = env.step(action)
           
            actions.append(action)
            states.append(state)
            rewards.append(reward)
            temp = 0 if terminal else 1
            terminals.append(temp)
            temp = 0 if truncate else 1
            truncates.append(temp)
            
        actions = np.array(actions,dtype=np.float32) 
        states = np.array(states,dtype=np.float32)
        rewards = np.array(rewards,dtype=np.float32)
        terminals = np.array(terminals,dtype=np.float32)
        truncates = np.array(truncates,dtype=np.float32)
        
        trajectories.append({'actions':actions,
                             'observations':states,
                             'rewards':rewards,
                             'terminals':terminals})
        print(f'{i+1} epsodes collected')
    return trajectories

def collect_trajectory(env,ep_num,trajectories,policy=None,device=None,state_mean=0, state_std=0,target_return=None,rand_act=None):
    if policy == None:
        trajectories = _random_collect(env,ep_num,trajectories)
    else:
        # device = 'cpu' if device == None else 'cuda'
        trajectories = _policy_collect(env,ep_num,trajectories,policy,device,state_mean, state_std,target_return,rand_act)
    print('='*50)
    print('Finish Collect')
    print('='*50)
    return trajectories

    
def _policy_collect(env,ep_num,trajectories,policy,device,state_mean, state_std,target_return,rand_act):
    state_dim = env.observation_space.shape[0]
    act_dim = env.action_space.shape[0]
    # target_return = 0.
    scale = 1000.  # normalization for rewards/returns
    

    policy.eval()
    policy.to(device=device)

    state_mean = torch.from_numpy(state_mean).to(device=device)
    state_std = torch.from_numpy(state_std).to(device=device)

    for i in range(ep_num):
        state, share_state = env.reset()
        state = state[0]
        state = state[0,:]
        
        # we keep all the histories on the device
        # note that the latest action and reward will be "padding"
        # print(state.shape,share_state.shape)
        states_tensor = torch.from_numpy(state).reshape(1, state_dim).to(device=device, dtype=torch.float32)
        actions_tensor = torch.zeros((0, act_dim), device=device, dtype=torch.float32)
        rewards_tensor = torch.zeros(0, device=device, dtype=torch.float32)
    
        actions = []
        states = []
        rewards = []
        terminals = []
        truncates = []
    
        ep_return = target_return
        target_return_tensor = torch.tensor(ep_return, device=device, dtype=torch.float32).reshape(1, 1)
        timesteps_tensor = torch.tensor(0, device=device, dtype=torch.long).reshape(1, 1)
    
        episode_return, steps = 0, 0.
        terminal, truncate = False, False
        while not terminal and not truncate: 
    
            # add padding
            actions_tensor = torch.cat([actions_tensor, torch.zeros((1, act_dim), device=device)], dim=0)
            rewards_tensor = torch.cat([rewards_tensor, torch.zeros(1, device=device)])
            # print(t,states_tensor.shape,actions_tensor.shape,rewards_tensor.shape,target_return_tensor.shape,timesteps_tensor.shape)
            # if rand_act > np.random.rand():
            action = policy.get_action(
                (states_tensor.to(dtype=torch.float32) - state_mean) / state_std,
                actions_tensor.to(dtype=torch.float32),
                rewards_tensor.to(dtype=torch.float32),
                target_return_tensor.to(dtype=torch.float32),
                timesteps_tensor.to(dtype=torch.long),
            )
        
            actions_tensor[-1] = action
            action = action.detach().clone().cpu().numpy()
            # else:
            #     action = env.action_space.sample()
            #     actions_tensor[-1] = torch.from_numpy(action)
                # print('radom',steps)
            
    
            state, share_state, reward, terminal, truncate, _ = env.step(action)
            # reward = reward - 1/10
            actions.append(action)
            states.append(state)
            rewards.append(reward)
            temp = 0 if terminal else 1
            terminals.append(temp)
            temp = 0 if terminal else 1
            truncates.append(temp)
    
    
            cur_state = torch.from_numpy(state).to(device=device).reshape(1, state_dim)
            states_tensor = torch.cat([states_tensor, cur_state], dim=0)
            rewards_tensor[-1] = reward
    
    
            pred_return = target_return_tensor[0,-1] - (reward/scale)
    
            target_return_tensor = torch.cat(
                [target_return_tensor, pred_return.reshape(1, 1)], dim=1)
            timesteps_tensor = torch.cat(
                [timesteps_tensor,
                 torch.ones((1, 1), device=device, dtype=torch.long) * (steps+1)], dim=1)
    
            episode_return += reward
            steps += 1
    
    
        actions = np.array(actions,dtype=np.float32) 
        states = np.array(states,dtype=np.float32)
        rewards = np.array(rewards,dtype=np.float32)
        terminals = np.array(terminals,dtype=np.float32)
        truncates = np.array(truncates,dtype=np.float32)
        
        trajectories.append({'actions':actions,
                             'observations':states,
                             'rewards':rewards,
                             'terminals':terminals})

        print(f'{i+1} epsodes collected Returns :{episode_return}')
    return trajectories


def view_trajecory(env,ep_num,policy,device,state_mean, state_std,target_return):
    state_dim = env.observation_space.shape[0]
    act_dim = env.action_space.shape[0]
    # target_return = 0.
    scale = 1000.  # normalization for rewards/returns

    policy.eval()
    policy.to(device=device)

    state_mean = torch.from_numpy(state_mean).to(device=device)
    state_std = torch.from_numpy(state_std).to(device=device)

    for i in range(ep_num):
        state, share_state = env.reset()
        # state = state[0]
        state = state[0,:]
        
        # we keep all the histories on the device
        # note that the latest action and reward will be "padding"
        states_tensor = torch.from_numpy(state).reshape(1, state_dim).to(device=device, dtype=torch.float32)
        actions_tensor = torch.zeros((0, act_dim), device=device, dtype=torch.float32)
        rewards_tensor = torch.zeros(0, device=device, dtype=torch.float32)
    
        ep_return = target_return
        target_return_tensor = torch.tensor(ep_return, device=device, dtype=torch.float32).reshape(1, 1)
        timesteps_tensor = torch.tensor(0, device=device, dtype=torch.long).reshape(1, 1)
    
        episode_return, steps = 0, 0.
        terminal, truncate = False, False
        while not terminal and not truncate: 
    
            # add padding
            actions_tensor = torch.cat([actions_tensor, torch.zeros((1, act_dim), device=device)], dim=0)
            rewards_tensor = torch.cat([rewards_tensor, torch.zeros(1, device=device)])
            # print(t,states_tensor.shape,actions_tensor.shape,rewards_tensor.shape,target_return_tensor.shape,timesteps_tensor.shape)
            action = policy.get_action(
                (states_tensor.to(dtype=torch.float32) - state_mean) / state_std,
                actions_tensor.to(dtype=torch.float32),
                rewards_tensor.to(dtype=torch.float32),
                target_return_tensor.to(dtype=torch.float32),
                timesteps_tensor.to(dtype=torch.long),
            )
            actions_tensor[-1] = action
            action = action.detach().cpu().numpy()
    
            state, share_state, reward, terminal, truncate, _ = env.step(action)
            # reward = reward - 1/10
    
            cur_state = torch.from_numpy(state).to(device=device).reshape(1, state_dim)
            states_tensor = torch.cat([states_tensor, cur_state], dim=0)
            rewards_tensor[-1] = reward
    
    
            pred_return = target_return_tensor[0,-1] - (reward/scale)
    
            target_return_tensor = torch.cat(
                [target_return_tensor, pred_return.reshape(1, 1)], dim=1)
            timesteps_tensor = torch.cat(
                [timesteps_tensor,
                 torch.ones((1, 1), device=device, dtype=torch.long) * (steps+1)], dim=1)
    
            episode_return += reward
            steps += 1
            # print(steps, reward)
            env.render()
        print(f'{i+1} epsodes End Returns :{episode_return}')
